package com.personale.musica.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.Player
import com.personale.musica.data.Song
import com.personale.musica.data.toMediaItem
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

/** Stato del lettore osservabile dall'interfaccia. */
@Stable
class PlayerUiState {
    var hasItem by mutableStateOf(false)
    var mediaId by mutableStateOf<String?>(null)
    var title by mutableStateOf("")
    var artist by mutableStateOf("")
    var isPlaying by mutableStateOf(false)
    var durationMs by mutableLongStateOf(0L)
    var positionMs by mutableLongStateOf(0L)
    var shuffle by mutableStateOf(false)
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)

    val progress: Float
        get() = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    fun sync(p: Player) {
        val item = p.currentMediaItem
        hasItem = item != null
        mediaId = item?.mediaId
        title = (p.mediaMetadata.title ?: item?.mediaMetadata?.title)?.toString() ?: ""
        artist = (p.mediaMetadata.artist ?: item?.mediaMetadata?.artist)?.toString() ?: ""
        isPlaying = p.playWhenReady && p.playbackState != Player.STATE_ENDED
        durationMs = if (p.duration == C.TIME_UNSET) 0L else p.duration
        positionMs = p.currentPosition
        shuffle = p.shuffleModeEnabled
        repeatMode = p.repeatMode
    }

    fun reset() {
        hasItem = false
        mediaId = null
        isPlaying = false
    }
}

@Composable
fun rememberPlayerState(player: Player?): PlayerUiState {
    val state = remember { PlayerUiState() }

    DisposableEffect(player) {
        if (player == null) {
            state.reset()
            return@DisposableEffect onDispose { }
        }
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                state.sync(player)
            }
        }
        state.sync(player)
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    // Aggiorna la barra di avanzamento mentre suona.
    LaunchedEffect(player, state.isPlaying) {
        if (player == null) return@LaunchedEffect
        while (isActive) {
            state.positionMs = player.currentPosition
            if (!state.isPlaying) break
            delay(500)
        }
    }
    return state
}

fun Player.playSongs(songs: List<Song>, startIndex: Int, shuffle: Boolean) {
    if (songs.isEmpty()) return
    shuffleModeEnabled = shuffle
    setMediaItems(songs.map { it.toMediaItem() }, startIndex.coerceIn(0, songs.lastIndex), 0L)
    prepare()
    play()
}

fun Player.togglePlayPause() {
    if (playWhenReady && playbackState != Player.STATE_ENDED) {
        pause()
    } else {
        if (playbackState == Player.STATE_IDLE) prepare()
        if (playbackState == Player.STATE_ENDED) seekToDefaultPosition(0)
        play()
    }
}

fun Player.cycleRepeat() {
    repeatMode = when (repeatMode) {
        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
        else -> Player.REPEAT_MODE_OFF
    }
}

fun formatDuration(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
