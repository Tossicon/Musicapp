package com.personale.musica.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Carica le copertine incorporate nei file audio, con una piccola cache in memoria. */
object ArtworkLoader {

    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    private val missing: MutableSet<String> = ConcurrentHashMap.newKeySet()

    fun cached(key: String, size: Int): Bitmap? = cache.get("$key@$size")

    suspend fun load(context: Context, key: String, uri: Uri, size: Int): Bitmap? {
        val cacheKey = "$key@$size"
        cache.get(cacheKey)?.let { return it }
        if (cacheKey in missing) return null
        val appContext = context.applicationContext
        return withContext(Dispatchers.IO) {
            val bitmap = try {
                decode(appContext, uri, size)
            } catch (e: Exception) {
                null
            }
            if (bitmap != null) cache.put(cacheKey, bitmap) else missing.add(cacheKey)
            bitmap
        }
    }

    private fun decode(context: Context, uri: Uri, size: Int): Bitmap? {
        if (Build.VERSION.SDK_INT >= 29) {
            return try {
                context.contentResolver.loadThumbnail(uri, Size(size, size), null)
            } catch (e: Exception) {
                null
            }
        }
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val bytes = retriever.embeddedPicture ?: return null
            return decodeSampled(bytes, size)
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {
                // ignorato
            }
        }
    }

    private fun decodeSampled(bytes: ByteArray, size: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= size && bounds.outHeight / (sample * 2) >= size) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
    }
}
