package com.personale.musica.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

// Posizioni degli elementi del parco lungo la barra (0 = inizio brano, 1 = fine).
private const val BOX0 = 0.17f
private const val BOX1 = 0.34f
private const val RAMP0 = 0.49f
private const val RAMP1 = 0.58f
private const val GAP1 = 0.74f

@Composable
fun SkateparkSeekBar(
    positionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val shown = (drag ?: fraction).coerceIn(0f, 1f)

    val orange = cs.primary
    val gray = cs.onSurfaceVariant.copy(alpha = 0.5f)
    val dark = Color(0xFF191919)
    val skin = Color(0xFFF5C6A0)

    Column(modifier) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(78.dp)
                .pointerInput(durationMs) {
                    detectTapGestures { o ->
                        if (durationMs > 0) onSeek((fracOf(o.x, size.width.toFloat()) * durationMs).toLong())
                    }
                }
                .pointerInput(durationMs) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> drag = fracOf(o.x, size.width.toFloat()) },
                        onHorizontalDrag = { ch, _ -> drag = fracOf(ch.position.x, size.width.toFloat()) },
                        onDragEnd = {
                            val f = drag
                            if (f != null && durationMs > 0) onSeek((f * durationMs).toLong())
                            drag = null
                        },
                        onDragCancel = { drag = null },
                    )
                },
        ) {
            drawSkatepark(shown, orange, gray, dark, skin)
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(formatDuration((shown * durationMs).toLong()), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            Text(formatDuration(durationMs), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }
}

private fun Density.fracOf(x: Float, widthPx: Float): Float {
    val pad = 20.dp.toPx()
    val track = (widthPx - 2 * pad).coerceAtLeast(1f)
    return ((x - pad) / track).coerceIn(0f, 1f)
}

// Altezza dello skater sopra il terreno in base al punto del brano (box, rampa, salto).
private fun lift(f: Float, boxH: Float, rampLip: Float, jumpH: Float): Float = when {
    f <= BOX0 -> 0f
    f <= BOX1 -> boxH
    f < RAMP0 -> 0f
    f <= RAMP1 -> rampLip * ((f - RAMP0) / (RAMP1 - RAMP0))
    f <= GAP1 -> {
        val t = (f - RAMP1) / (GAP1 - RAMP1)
        rampLip * (1f - t) + sin(t * PI).toFloat() * jumpH
    }
    else -> 0f
}

private fun DrawScope.drawSkatepark(shown: Float, orange: Color, gray: Color, dark: Color, skin: Color) {
    val pad = 20.dp.toPx()
    val w = size.width
    val track = (w - 2 * pad).coerceAtLeast(1f)
    val baseY = size.height * 0.56f
    val boxH = 11.dp.toPx()
    val rampLip = 14.dp.toPx()
    val jumpH = 26.dp.toPx()
    val gw = 4f.dp.toPx()
    fun x(f: Float) = pad + f.coerceIn(0f, 1f) * track
    fun gline(a: Float, b: Float, y: Float, c: Color) =
        drawLine(c, Offset(x(a), y), Offset(x(b), y), strokeWidth = gw, cap = StrokeCap.Round)

    // rampe laterali (quarti di tubo)
    val rr = 22.dp.toPx()
    drawPath(
        Path().apply {
            moveTo(pad, baseY); lineTo(pad, baseY - rr)
            quadraticBezierTo(pad, baseY, pad + rr, baseY); close()
        },
        gray,
    )
    drawPath(
        Path().apply {
            moveTo(w - pad, baseY); lineTo(w - pad, baseY - rr)
            quadraticBezierTo(w - pad, baseY, w - pad - rr, baseY); close()
        },
        gray,
    )

    // terreno grigio con il buco del gap
    gline(0f, BOX0, baseY, gray)
    drawRoundRect(
        color = gray,
        topLeft = Offset(x(BOX0), baseY - boxH),
        size = Size(x(BOX1) - x(BOX0), boxH + 3.dp.toPx()),
        cornerRadius = CornerRadius(3.dp.toPx()),
    )
    gline(BOX0, BOX1, baseY - boxH, gray)
    gline(BOX1, RAMP0, baseY, gray)
    drawPath(
        Path().apply {
            moveTo(x(RAMP0), baseY); lineTo(x(RAMP1), baseY); lineTo(x(RAMP1), baseY - rampLip); close()
        },
        gray,
    )
    gline(GAP1, 1f, baseY, gray)

    // scia arancione: segue il percorso (terra, box, rampa, salto) fino al punto attuale
    val trail = Path()
    var started = false
    var f = 0f
    while (f <= shown + 0.0001f) {
        val px = x(f)
        val py = baseY - lift(f, boxH, rampLip, jumpH)
        if (!started) { trail.moveTo(px, py); started = true } else trail.lineTo(px, py)
        f += 0.01f
    }
    if (started) {
        drawPath(trail, dark, style = Stroke(width = gw + 3.dp.toPx(), cap = StrokeCap.Round))
        drawPath(trail, orange, style = Stroke(width = gw, cap = StrokeCap.Round))
    }

    // skater
    drawSkater(x(shown), baseY - lift(shown, boxH, rampLip, jumpH), orange, dark, skin)
}

private fun DrawScope.drawSkater(px: Float, py: Float, orange: Color, dark: Color, skin: Color) {
    val white = Color(0xFFEDEDED)
    val boardLen = 22.dp.toPx()
    val wheelR = 2.6f.dp.toPx()
    fun dp(v: Float) = v.dp.toPx()

    // skateboard: deck + due ruote (ben riconoscibile di profilo)
    drawRoundRect(
        color = dark,
        topLeft = Offset(px - boardLen / 2, py - dp(1.5f)),
        size = Size(boardLen, dp(3.2f)),
        cornerRadius = CornerRadius(dp(2f)),
    )
    drawCircle(white, wheelR, Offset(px - boardLen / 2 + dp(4f), py + dp(2f)))
    drawCircle(white, wheelR, Offset(px + boardLen / 2 - dp(4f), py + dp(2f)))

    // gambe
    val hipY = py - dp(13f)
    drawLine(dark, Offset(px - dp(4f), py - dp(1.5f)), Offset(px - dp(3f), hipY), strokeWidth = dp(3f), cap = StrokeCap.Round)
    drawLine(dark, Offset(px + dp(4f), py - dp(1.5f)), Offset(px + dp(3f), hipY), strokeWidth = dp(3f), cap = StrokeCap.Round)
    // felpa arancione
    drawRoundRect(orange, topLeft = Offset(px - dp(5f), hipY - dp(9f)), size = Size(dp(10f), dp(11f)), cornerRadius = CornerRadius(dp(4f)))
    // braccia
    drawLine(skin, Offset(px - dp(3f), hipY - dp(6f)), Offset(px - dp(9f), hipY - dp(3f)), strokeWidth = dp(2.6f), cap = StrokeCap.Round)
    drawLine(skin, Offset(px + dp(3f), hipY - dp(7f)), Offset(px + dp(9f), hipY - dp(10f)), strokeWidth = dp(2.6f), cap = StrokeCap.Round)
    // testa + cappellino
    drawCircle(skin, dp(3.4f), Offset(px + dp(1f), hipY - dp(13f)))
    drawArc(
        color = dark,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(px - dp(3f), hipY - dp(17f)),
        size = Size(dp(8f), dp(8f)),
    )
}
