package com.personale.musica.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.personale.musica.data.Song

@Composable
fun MiniPlayer(state: PlayerUiState, song: Song?, player: Player?, onOpen: () -> Unit) {
    Surface(
        onClick = onOpen,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
    ) {
        Column {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                AlbumArt(song, Modifier.size(44.dp))
                Column(
                    Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp)
                ) {
                    Text(
                        state.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        state.artist,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = { player?.togglePlayPause() }) {
                    Icon(
                        if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (state.isPlaying) "Pausa" else "Riproduci",
                    )
                }
                IconButton(onClick = { player?.seekToNext() }) {
                    Icon(Icons.Rounded.SkipNext, contentDescription = "Successivo")
                }
            }
            ProgressLine(
                state.progress,
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
            )
        }
    }
}

@Composable
fun NowPlayingScreen(state: PlayerUiState, song: Song?, player: Player?, onClose: () -> Unit) {
    val colors = MaterialTheme.colorScheme

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF3A2A1E), Color(0xFF2A2320), colors.background)))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Chiudi")
            }
            Text(
                "In riproduzione",
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelLarge,
            )
            Spacer(Modifier.width(48.dp))
        }

        Spacer(Modifier.weight(1f))

        Turntable(
            song = song,
            isPlaying = state.isPlaying,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .aspectRatio(1f),
        )

        Spacer(Modifier.height(28.dp))

        Column(Modifier.fillMaxWidth()) {
            Text(
                state.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                state.artist,
                style = MaterialTheme.typography.titleMedium,
                color = colors.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Spacer(Modifier.height(16.dp))

        SkateparkSeekBar(
            positionMs = state.positionMs,
            durationMs = state.durationMs,
            onSeek = { player?.seekTo(it) },
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(14.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TapeKey(onClick = { player?.shuffleModeEnabled = !state.shuffle }, width = 46.dp, height = 40.dp, bg = colors.surfaceVariant) {
                Icon(
                    Icons.Rounded.Shuffle, "Casuale", modifier = Modifier.size(20.dp),
                    tint = if (state.shuffle) colors.primary else colors.onSurfaceVariant,
                )
            }
            TapeKey(onClick = { player?.seekToPrevious() }, width = 58.dp, height = 48.dp, bg = colors.surfaceVariant) {
                Icon(Icons.Rounded.SkipPrevious, "Precedente", modifier = Modifier.size(30.dp), tint = colors.onBackground)
            }
            TapeKey(onClick = { player?.togglePlayPause() }, width = 76.dp, height = 58.dp, bg = colors.primary) {
                Icon(
                    if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (state.isPlaying) "Pausa" else "Riproduci",
                    modifier = Modifier.size(34.dp), tint = colors.onPrimary,
                )
            }
            TapeKey(onClick = { player?.seekToNext() }, width = 58.dp, height = 48.dp, bg = colors.surfaceVariant) {
                Icon(Icons.Rounded.SkipNext, "Successivo", modifier = Modifier.size(30.dp), tint = colors.onBackground)
            }
            TapeKey(onClick = { player?.cycleRepeat() }, width = 46.dp, height = 40.dp, bg = colors.surfaceVariant) {
                Icon(
                    if (state.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Ripeti", modifier = Modifier.size(20.dp),
                    tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) colors.primary else colors.onSurfaceVariant,
                )
            }
        }

        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun TapeKey(
    onClick: () -> Unit,
    width: Dp,
    height: Dp,
    bg: Color,
    content: @Composable () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = bg,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.10f)),
        modifier = Modifier.size(width = width, height = height),
    ) {
        Box(contentAlignment = Alignment.Center) { content() }
    }
}
