package com.personale.musica.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personale.musica.data.Album
import com.personale.musica.data.Artist
import com.personale.musica.data.Song
import kotlin.random.Random

typealias PlayAction = (songs: List<Song>, startIndex: Int, shuffle: Boolean) -> Unit

@Composable
fun LibraryTabs(
    tab: Int,
    onTab: (Int) -> Unit,
    songs: List<Song>,
    albums: List<Album>,
    artists: List<Artist>,
    loading: Boolean,
    currentId: String?,
    onPlay: PlayAction,
    onAlbum: (Album) -> Unit,
    onArtist: (Artist) -> Unit,
    onRefresh: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "Mixtape",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onRefresh) {
                Icon(Icons.Rounded.Refresh, contentDescription = "Aggiorna libreria")
            }
        }
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Pill("Brani", tab == 0) { onTab(0) }
            Pill("Album", tab == 1) { onTab(1) }
            Pill("Artisti", tab == 2) { onTab(2) }
        }

        when {
            loading && songs.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            songs.isEmpty() -> EmptyLibrary()
            tab == 0 -> SongsTab(songs, currentId, onPlay)
            tab == 1 -> AlbumsGrid(albums, onAlbum)
            else -> ArtistsList(artists, onArtist)
        }
    }
}

@Composable
private fun EmptyLibrary() {
    Box(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "Nessun brano trovato.\n\nCopia i tuoi file musicali nella cartella Music del telefono " +
                "(o sulla scheda SD), poi tocca ↻ in alto.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SongsTab(songs: List<Song>, currentId: String?, onPlay: PlayAction) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(songs, query) {
        if (query.isBlank()) songs
        else songs.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true) ||
                it.album.contains(query, ignoreCase = true)
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Cerca brani, artisti, album") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Cancella")
                        }
                    }
                },
                singleLine = true,
                shape = CircleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
            )
        }
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable(enabled = filtered.isNotEmpty()) {
                        onPlay(filtered, Random.nextInt(filtered.size), true)
                    }
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Shuffle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Text(
                    "Riproduzione casuale  ·  ${filtered.size} brani",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
        itemsIndexed(filtered, key = { _, s -> s.id }) { index, song ->
            SongRow(song, song.id.toString() == currentId, onClick = { onPlay(filtered, index, false) })
        }
    }
}

@Composable
private fun AlbumsGrid(albums: List<Album>, onAlbum: (Album) -> Unit) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(150.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        items(albums.size, key = { albums[it].id }) { i ->
            val album = albums[i]
            Column(Modifier.clickable { onAlbum(album) }) {
                AlbumArt(
                    album.songs.first(),
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f),
                    corner = 10.dp,
                    sizePx = 384,
                )
                Text(
                    album.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp),
                )
                Text(
                    album.artist,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ArtistsList(artists: List<Artist>, onArtist: (Artist) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        items(artists, key = { it.name }) { artist ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { onArtist(artist) }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AlbumArt(artist.songs.first(), Modifier.size(56.dp), circle = true)
                Column(Modifier.padding(start = 14.dp)) {
                    Text(artist.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${artist.albumCount} album · ${artist.songs.size} brani",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
fun AlbumDetail(album: Album, currentId: String?, onBack: () -> Unit, onPlay: PlayAction) {
    val totalMs = remember(album) { album.songs.sumOf { it.durationMs } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { BackBar(onBack) }
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                AlbumArt(album.songs.first(), Modifier.size(220.dp), corner = 14.dp, sizePx = 512)
                Spacer(Modifier.height(16.dp))
                Text(
                    album.title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )
                Text(album.artist, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "${album.songs.size} brani · ${formatDuration(totalMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                PlayShuffleButtons(
                    onPlay = { onPlay(album.songs, 0, false) },
                    onShuffle = { onPlay(album.songs, Random.nextInt(album.songs.size), true) },
                )
                Spacer(Modifier.height(8.dp))
            }
        }
        itemsIndexed(album.songs, key = { _, s -> s.id }) { index, song ->
            SongRow(
                song,
                song.id.toString() == currentId,
                onClick = { onPlay(album.songs, index, false) },
                leading = {
                    Box(Modifier.size(32.dp), contentAlignment = Alignment.Center) {
                        val number = if (song.track > 0) song.track % 1000 else index + 1
                        Text("$number", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
            )
        }
    }
}

@Composable
fun ArtistDetail(
    artist: Artist,
    allAlbums: List<Album>,
    currentId: String?,
    onBack: () -> Unit,
    onPlay: PlayAction,
    onAlbum: (Album) -> Unit,
) {
    val albums = remember(artist, allAlbums) {
        val ids = artist.songs.map { it.albumId }.toSet()
        allAlbums.filter { it.id in ids }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { BackBar(onBack) }
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                AlbumArt(artist.songs.first(), Modifier.size(160.dp), sizePx = 384, circle = true)
                Spacer(Modifier.height(16.dp))
                Text(
                    artist.name,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                )
                Text(
                    "${artist.albumCount} album · ${artist.songs.size} brani",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(16.dp))
                PlayShuffleButtons(
                    onPlay = { onPlay(artist.songs, 0, false) },
                    onShuffle = { onPlay(artist.songs, Random.nextInt(artist.songs.size), true) },
                )
            }
        }
        if (albums.size > 1) {
            item {
                Text(
                    "Album",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 8.dp),
                )
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(albums, key = { it.id }) { album ->
                        Column(
                            Modifier
                                .width(130.dp)
                                .clickable { onAlbum(album) }
                        ) {
                            AlbumArt(album.songs.first(), Modifier.size(130.dp), corner = 10.dp, sizePx = 384)
                            Text(
                                album.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 6.dp),
                            )
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Brani",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 4.dp),
            )
        }
        itemsIndexed(artist.songs, key = { _, s -> s.id }) { index, song ->
            SongRow(song, song.id.toString() == currentId, onClick = { onPlay(artist.songs, index, false) })
        }
    }
}
