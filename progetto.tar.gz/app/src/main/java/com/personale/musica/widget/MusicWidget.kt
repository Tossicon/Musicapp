package com.personale.musica.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews
import androidx.media3.common.Player
import com.personale.musica.R
import com.personale.musica.playback.PlayerHolder
import com.personale.musica.ui.MainActivity

data class WidgetState(
    val mediaId: String,
    val title: String,
    val artist: String,
    val isPlaying: Boolean,
    val art: Bitmap?,
)

object MusicWidget {
    const val ACTION_PLAY_PAUSE = "com.personale.musica.widget.PLAY_PAUSE"
    const val ACTION_NEXT = "com.personale.musica.widget.NEXT"
    const val ACTION_PREV = "com.personale.musica.widget.PREV"

    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    @Volatile
    var lastState: WidgetState? = null
        private set

    fun update(context: Context, state: WidgetState?) {
        lastState = state
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, MusicWidgetProvider::class.java))
        if (ids.isEmpty()) return
        manager.updateAppWidget(ids, build(context, state))
    }

    private fun build(context: Context, state: WidgetState?): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_music)

        val openApp = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            FLAGS,
        )
        views.setOnClickPendingIntent(R.id.widget_root, openApp)
        views.setOnClickPendingIntent(R.id.widget_art, openApp)

        if (state == null) {
            views.setTextViewText(R.id.widget_title, context.getString(R.string.widget_idle_title))
            views.setTextViewText(R.id.widget_artist, context.getString(R.string.widget_idle_subtitle))
            views.setImageViewResource(R.id.widget_art, R.drawable.ic_widget_note)
            views.setImageViewResource(R.id.widget_play, R.drawable.ic_widget_play)
            // Nessun brano in coda: qualsiasi tasto apre l'app per sceglierne uno.
            views.setOnClickPendingIntent(R.id.widget_prev, openApp)
            views.setOnClickPendingIntent(R.id.widget_play, openApp)
            views.setOnClickPendingIntent(R.id.widget_next, openApp)
        } else {
            views.setTextViewText(R.id.widget_title, state.title)
            views.setTextViewText(R.id.widget_artist, state.artist)
            if (state.art != null) {
                views.setImageViewBitmap(R.id.widget_art, state.art)
            } else {
                views.setImageViewResource(R.id.widget_art, R.drawable.ic_widget_note)
            }
            views.setImageViewResource(
                R.id.widget_play,
                if (state.isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play,
            )
            views.setOnClickPendingIntent(R.id.widget_prev, command(context, ACTION_PREV, 1))
            views.setOnClickPendingIntent(R.id.widget_play, command(context, ACTION_PLAY_PAUSE, 2))
            views.setOnClickPendingIntent(R.id.widget_next, command(context, ACTION_NEXT, 3))
        }
        return views
    }

    private fun command(context: Context, action: String, requestCode: Int): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            requestCode,
            Intent(context, MusicWidgetProvider::class.java).setAction(action),
            FLAGS,
        )
}

class MusicWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val active = PlayerHolder.player?.currentMediaItem != null
        MusicWidget.update(context, if (active) MusicWidget.lastState else null)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action != MusicWidget.ACTION_PLAY_PAUSE &&
            action != MusicWidget.ACTION_NEXT &&
            action != MusicWidget.ACTION_PREV
        ) return

        val player = PlayerHolder.player
        if (player == null || player.mediaItemCount == 0) {
            // L'app è stata chiusa dal sistema: il widget torna allo stato "apri l'app".
            MusicWidget.update(context, null)
            return
        }

        when (action) {
            MusicWidget.ACTION_PLAY_PAUSE -> {
                if (player.playWhenReady && player.playbackState != Player.STATE_ENDED) {
                    player.pause()
                } else {
                    if (player.playbackState == Player.STATE_IDLE) player.prepare()
                    if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition(0)
                    player.play()
                }
            }
            MusicWidget.ACTION_NEXT -> player.seekToNext()
            MusicWidget.ACTION_PREV -> player.seekToPrevious()
        }
    }
}
