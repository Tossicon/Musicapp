package com.personale.musica.playback

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.personale.musica.data.ArtworkLoader
import com.personale.musica.data.MusicRepository
import com.personale.musica.data.artKey
import com.personale.musica.ui.MainActivity
import com.personale.musica.widget.MusicWidget
import com.personale.musica.widget.WidgetState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Riferimento al lettore attivo, usato dal widget per i comandi play/pausa/avanti/indietro. */
object PlayerHolder {
    @Volatile
    var player: Player? = null
}

/**
 * Servizio che suona la musica anche con l'app chiusa o lo schermo spento.
 * Media3 crea automaticamente la notifica con i controlli e gestisce cuffie e Bluetooth.
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var artJob: Job? = null

    override fun onCreate() {
        super.onCreate()

        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true) // pausa se stacchi le cuffie
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        player.addListener(object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                if (events.containsAny(
                        Player.EVENT_MEDIA_ITEM_TRANSITION,
                        Player.EVENT_PLAY_WHEN_READY_CHANGED,
                        Player.EVENT_PLAYBACK_STATE_CHANGED,
                        Player.EVENT_MEDIA_METADATA_CHANGED,
                    )
                ) {
                    updateWidget()
                }
            }
        })

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        session = MediaSession.Builder(this, player)
            .setSessionActivity(openApp)
            .setCallback(SessionCallback())
            .build()

        PlayerHolder.player = player
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Se togli l'app dalle recenti mentre è in pausa, chiudi tutto.
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        PlayerHolder.player = null
        scope.cancel()
        session?.run {
            player.release()
            release()
        }
        session = null
        MusicWidget.update(this, null)
        super.onDestroy()
    }

    private fun updateWidget() {
        val player = session?.player ?: return
        val item = player.currentMediaItem
        if (item == null) {
            MusicWidget.update(this, null)
            return
        }
        val metadata = player.mediaMetadata
        val title = (metadata.title ?: item.mediaMetadata.title)?.toString() ?: "Senza titolo"
        val artist = (metadata.artist ?: item.mediaMetadata.artist)?.toString() ?: ""
        val playing = player.playWhenReady && player.playbackState != Player.STATE_ENDED
        val mediaId = item.mediaId

        val previousArt = MusicWidget.lastState?.takeIf { it.mediaId == mediaId }?.art
        MusicWidget.update(this, WidgetState(mediaId, title, artist, playing, previousArt))

        if (previousArt == null) {
            artJob?.cancel()
            artJob = scope.launch {
                val id = mediaId.toLongOrNull() ?: return@launch
                val song = MusicRepository.songById(id)
                val key = song?.artKey ?: "s$id"
                val uri = song?.uri ?: MusicRepository.songUri(id)
                val art = ArtworkLoader.load(this@PlaybackService, key, uri, 256) ?: return@launch
                val current = MusicWidget.lastState ?: return@launch
                if (current.mediaId == mediaId) {
                    MusicWidget.update(this@PlaybackService, current.copy(art = art))
                }
            }
        }
    }

    private inner class SessionCallback : MediaSession.Callback {
        // L'interfaccia invia solo l'ID del brano: qui ricostruiamo il percorso del file.
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val resolved = mediaItems.map { item ->
                val id = item.mediaId.toLongOrNull()
                if (item.localConfiguration != null || id == null) {
                    item
                } else {
                    item.buildUpon().setUri(MusicRepository.songUri(id)).build()
                }
            }.toMutableList()
            return Futures.immediateFuture(resolved)
        }
    }
}
