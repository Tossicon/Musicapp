package com.personale.musica.data

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val albumArtist: String = "",
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val track: Int,
    val genre: String = "",
    val uri: Uri,
)

data class Genre(
    val name: String,
    val songs: List<Song>,
)

data class Album(
    val id: Long,
    val title: String,
    val artist: String,
    val songs: List<Song>,
)

data class Artist(
    val name: String,
    val songs: List<Song>,
    val albumCount: Int,
)

/** Chiave usata per la copertina: i brani dello stesso album la condividono. */
val Song.artKey: String get() = "a$albumId"

fun Song.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .build()
        )
        .build()
