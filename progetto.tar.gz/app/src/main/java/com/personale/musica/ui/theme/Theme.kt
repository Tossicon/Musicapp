package com.personale.musica.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palette: sfondo grigio scuro #212121, accento arancione. Cambia qui.
val Accent = Color(0xFFFF7A3D)   // arancio caldo
val Accent2 = Color(0xFF53C6B3)  // teal secondario
val Background = Color(0xFF212121) // grigio scuro

private val ColorScheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF1A0E06),
    secondary = Accent2,
    onSecondary = Color(0xFF05201C),
    background = Background,
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF2A2A2A),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF363636),
    onSurfaceVariant = Color(0xFFB2B2B2),
)

@Composable
fun MusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ColorScheme, content = content)
}
