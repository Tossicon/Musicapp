package com.personale.musica.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palette retrò/lo-fi, in tinta con il widget. Cambia qui per personalizzare.
val Accent = Color(0xFFFF7A3D)   // arancio caldo
val Accent2 = Color(0xFF53C6B3)  // teal secondario
val Background = Color(0xFF14110D) // nero caldo

private val ColorScheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF1A0E06),
    secondary = Accent2,
    onSecondary = Color(0xFF05201C),
    background = Background,
    onBackground = Color(0xFFF4EEE4),
    surface = Color(0xFF1E1A14),
    onSurface = Color(0xFFF4EEE4),
    surfaceVariant = Color(0xFF2A251D),
    onSurfaceVariant = Color(0xFFB2A892),
)

@Composable
fun MusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ColorScheme, content = content)
}
