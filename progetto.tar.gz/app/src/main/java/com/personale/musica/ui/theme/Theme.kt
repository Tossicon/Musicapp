package com.personale.musica.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Palette: sfondo grigio scuro #212121, accento arancione. Cambia qui.
val Accent = Color(0xFFFF7A3D)   // arancio caldo
val Accent2 = Color(0xFF53C6B3)  // teal secondario
val Background = Color(0xFF272727) // grigio scuro

private val ColorScheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF1A0E06),
    secondary = Accent2,
    onSecondary = Color(0xFF05201C),
    background = Background,
    onBackground = Color(0xFFF2F2F2),
    surface = Color(0xFF333333),
    onSurface = Color(0xFFF2F2F2),
    surfaceVariant = Color(0xFF3D3D3D),
    onSurfaceVariant = Color(0xFFBEBEBE),
)

@Composable
fun MusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ColorScheme, content = content)
}
