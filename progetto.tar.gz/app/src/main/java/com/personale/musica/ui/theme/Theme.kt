package com.personale.musica.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Cambia questi colori per personalizzare l'aspetto dell'app.
val Accent = Color(0xFFFF7A59)
val Background = Color(0xFF0D0E12)

private val ColorScheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF1A0E0A),
    secondary = Accent,
    onSecondary = Color(0xFF1A0E0A),
    background = Background,
    onBackground = Color(0xFFF2F2F5),
    surface = Color(0xFF15171C),
    onSurface = Color(0xFFF2F2F5),
    surfaceVariant = Color(0xFF22252D),
    onSurfaceVariant = Color(0xFF9EA2AD),
)

@Composable
fun MusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ColorScheme, content = content)
}
