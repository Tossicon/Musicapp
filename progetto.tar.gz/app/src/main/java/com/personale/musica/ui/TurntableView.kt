package com.personale.musica.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import com.personale.musica.data.Song

// Colori retrò del giradischi: puoi cambiarli qui.
private val Vinyl = Color(0xFF111114)
private val VinylEdge = Color(0xFF050507)
private val Gold = Color(0xFFE6B566)
private val Metal = Color(0xFFC4C7CE)
private val MetalDark = Color(0xFF6E7179)

/**
 * Giradischi: il vinile ruota a 33⅓ giri mentre la musica suona e si ferma in pausa,
 * tenendo la posizione. La copertina fa da etichetta al centro; il braccio si appoggia
 * sul disco quando suona e si solleva in pausa.
 */
@Composable
fun Turntable(song: Song?, isPlaying: Boolean, modifier: Modifier = Modifier) {
    var angle by remember { mutableFloatStateOf(0f) }

    // Avanza l'angolo fotogramma per fotogramma finché suona; fermandosi, l'angolo resta com'è.
    LaunchedEffect(isPlaying) {
        if (!isPlaying) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val deltaSeconds = (now - last) / 1_000_000_000f
            last = now
            angle = (angle + deltaSeconds * 200f) % 360f // 200°/s ≈ 33⅓ giri/min
        }
    }

    // 0 = braccio appoggiato (suona), 1 = braccio sollevato (pausa).
    val lift by animateFloatAsState(
        targetValue = if (isPlaying) 0f else 1f,
        animationSpec = tween(600),
        label = "lift",
    )

    Box(modifier, contentAlignment = Alignment.Center) {
        // Gruppo che ruota: vinile + etichetta.
        Box(
            Modifier
                .fillMaxSize()
                .aspectRatio(1f)
                .graphicsLayer { rotationZ = angle },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) { drawVinyl() }
            AlbumArt(song, Modifier.fillMaxSize(0.40f), sizePx = 512, circle = true)
            Canvas(Modifier.fillMaxSize()) {
                // Foro centrale del disco.
                drawCircle(VinylEdge, radius = size.minDimension * 0.014f, center = center)
            }
        }
        // Braccio: non ruota con il disco.
        Canvas(Modifier.fillMaxSize()) { drawTonearm(lift, isPlaying) }
    }
}

private fun DrawScope.drawVinyl() {
    val r = size.minDimension / 2f
    val c = center

    drawCircle(VinylEdge, r, c)
    drawCircle(Vinyl, r * 0.992f, c)

    // Solchi concentrici.
    val n = 26
    for (i in 0 until n) {
        val rr = r * (0.42f + 0.56f * i / (n - 1))
        val a = if (i % 2 == 0) 0.05f else 0.022f
        drawCircle(Color.White.copy(alpha = a), rr, c, style = Stroke(1.2f))
    }

    // Riflesso che ruota col disco: rende visibile la rotazione.
    val sheenR = r * 0.72f
    drawArc(
        color = Color.White.copy(alpha = 0.10f),
        startAngle = -25f,
        sweepAngle = 50f,
        useCenter = false,
        topLeft = Offset(c.x - sheenR, c.y - sheenR),
        size = androidx.compose.ui.geometry.Size(sheenR * 2, sheenR * 2),
        style = Stroke(width = r * 0.03f),
    )

    // Anello dorato attorno all'etichetta.
    drawCircle(Gold, r * 0.405f, c, style = Stroke(width = 2.5f))
}

private fun DrawScope.drawTonearm(lift: Float, isPlaying: Boolean) {
    val w = size.width
    val pivot = Offset(w * 0.85f, w * 0.12f)
    val restEnd = Offset(w * 0.57f, w * 0.40f) // testina sul disco quando suona

    rotate(degrees = 16f * lift, pivot = pivot) {
        // Contrappeso dietro il perno.
        val back = Offset(
            pivot.x + (pivot.x - restEnd.x) * 0.20f,
            pivot.y + (pivot.y - restEnd.y) * 0.20f,
        )
        drawLine(MetalDark, pivot, back, strokeWidth = w * 0.030f, cap = StrokeCap.Round)
        drawCircle(Color(0xFF34363C), radius = w * 0.030f, center = back)

        // Base/perno.
        drawCircle(MetalDark, radius = w * 0.038f, center = pivot)
        drawCircle(Metal, radius = w * 0.024f, center = pivot)

        // Braccio.
        drawLine(Metal, pivot, restEnd, strokeWidth = w * 0.013f, cap = StrokeCap.Round)

        // Testina.
        drawCircle(Color(0xFF2B2D33), radius = w * 0.032f, center = restEnd)
        drawCircle(if (isPlaying) Gold else MetalDark, radius = w * 0.013f, center = restEnd)
    }
}
