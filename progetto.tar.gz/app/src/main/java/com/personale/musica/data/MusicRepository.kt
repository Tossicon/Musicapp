package com.personale.musica.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/**
 * Legge la musica presente sul telefono tramite l'indice multimediale di Android
 * (MediaStore). Trova automaticamente i file in Music, Download, scheda SD, ecc.
 */
object MusicRepository {

    @Volatile
    private var byId: Map<Long, Song> = emptyMap()

    fun songUri(id: Long): Uri =
        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    fun songById(id: Long): Song? = byId[id]

    fun loadSongs(context: Context): List<Song> {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.ALBUM_ARTIST,
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val result = ArrayList<Song>()

        try {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder,
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val trackCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val albumArtistCol = c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ARTIST)

                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val albumArtist = if (albumArtistCol >= 0) c.getString(albumArtistCol).orEmpty() else ""
                    result += Song(
                        id = id,
                        title = c.getString(titleCol).orFallback("Senza titolo"),
                        artist = c.getString(artistCol).orFallback("Artista sconosciuto"),
                        albumArtist = albumArtist,
                        album = c.getString(albumCol).orFallback("Album sconosciuto"),
                        albumId = c.getLong(albumIdCol),
                        durationMs = c.getLong(durationCol),
                        track = c.getInt(trackCol),
                        uri = songUri(id),
                    )
                }
            }
        } catch (e: SecurityException) {
            return emptyList()
        }

        byId = result.associateBy { it.id }
        return result
    }

    fun albumsOf(songs: List<Song>): List<Album> =
        songs.groupBy { it.albumId }
            .map { (id, list) ->
                val sorted = list.sortedWith(compareBy<Song>({ it.track }, { it.title.lowercase() }))
                val mainArtist = list.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }?.key ?: ""
                Album(id, sorted.first().album, mainArtist, sorted)
            }
            .sortedBy { it.title.lowercase() }

    /**
     * Ogni brano viene elencato sotto OGNI artista che lo ha realizzato, così la scheda
     * di un artista contiene tutto il suo (brani da solo e in collaborazione).
     */
    fun artistsOf(songs: List<Song>): List<Artist> {
        val buckets = LinkedHashMap<String, MutableList<Song>>()
        val display = HashMap<String, String>()
        for (song in songs) {
            for (name in splitArtists(song)) {
                val key = name.lowercase()
                display.putIfAbsent(key, name)
                buckets.getOrPut(key) { mutableListOf() }.add(song)
            }
        }
        return buckets.map { (key, list) ->
            val uniq = list.distinctBy { it.id }
                .sortedWith(compareBy<Song>({ it.album.lowercase() }, { it.track }))
            Artist(display.getValue(key), uniq, uniq.map { it.albumId }.distinct().size)
        }.sortedBy { it.name.lowercase() }
    }

    private val featRegex =
        Regex("(?i)\\s*\\b(feat|ft|featuring|with|w/|f/|pres|presents|vs)\\b\\.?\\s*")
    private val commaRegex = Regex("(?i),\\s*(?!the\\b)") // virgola, ma non "X, The Y"
    private val symbolRegex = Regex("\\s*[&/;+×]\\s*")
    private val xRegex = Regex("(?i)\\s+x\\s+")
    private val artistStopwords = setOf("various artists", "va", "unknown", "<unknown>", "the")

    /** Estrae i singoli nomi d'artista da un brano, da tag artista e album-artist. */
    private fun splitArtists(song: Song): List<String> {
        val sources = buildList {
            val aa = song.albumArtist.trim()
            if (aa.isNotBlank() && !aa.equals("<unknown>", true) && aa != MediaStore.UNKNOWN_STRING) add(aa)
            add(song.artist)
        }.joinToString(";")

        val normalized = sources
            .replace(featRegex, "|")
            .replace(commaRegex, "|")
            .replace(symbolRegex, "|")
            .replace(xRegex, "|")

        val names = normalized.split("|")
            .map { it.trim().trim(',', '-', '·', ' ') }
            .filter { it.isNotBlank() && it.lowercase() !in artistStopwords }
            .distinctBy { it.lowercase() }

        return names.ifEmpty { listOf(song.artist) }
    }

    private fun String?.orFallback(fallback: String): String =
        if (this.isNullOrBlank() || this == MediaStore.UNKNOWN_STRING) fallback else this
}
