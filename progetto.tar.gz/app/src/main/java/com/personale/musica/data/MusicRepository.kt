package com.personale.musica.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/**
 * Legge la musica presente sul telefono tramite l'indice multimediale di Android
 * (MediaStore). Trova automaticamente i file in Music, Download, scheda SD, ecc.
 */
object MusicRepository {

    @Volatile
    private var byId: Map<Long, Song> = emptyMap()

    fun songUri(id: Long): Uri =
        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

    fun songById(id: Long): Song? = byId[id]

    fun loadSongs(context: Context): List<Song> {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.ALBUM_ARTIST,
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val result = ArrayList<Song>()

        try {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                sortOrder,
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val trackCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val albumArtistCol = c.getColumnIndex(MediaStore.Audio.Media.ALBUM_ARTIST)

                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val albumArtist = if (albumArtistCol >= 0) c.getString(albumArtistCol).orEmpty() else ""
                    result += Song(
                        id = id,
                        title = c.getString(titleCol).orFallback("Senza titolo"),
                        artist = c.getString(artistCol).orFallback("Artista sconosciuto"),
                        albumArtist = albumArtist,
                        album = c.getString(albumCol).orFallback("Album sconosciuto"),
                        albumId = c.getLong(albumIdCol),
                        durationMs = c.getLong(durationCol),
                        track = c.getInt(trackCol),
                        uri = songUri(id),
                    )
                }
            }
        } catch (e: SecurityException) {
            return emptyList()
        }

        byId = result.associateBy { it.id }
        return result
    }

    fun albumsOf(songs: List<Song>): List<Album> =
        songs.groupBy { it.albumId }
            .map { (id, list) ->
                val sorted = list.sortedWith(compareBy<Song>({ it.track }, { it.title.lowercase() }))
                val mainArtist = list.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }?.key ?: ""
                Album(id, sorted.first().album, mainArtist, sorted)
            }
            .sortedBy { it.title.lowercase() }

    fun artistsOf(songs: List<Song>): List<Artist> =
        songs.groupBy { primaryArtistName(it) }
            .map { (name, list) ->
                val sorted = list.sortedWith(compareBy<Song>({ it.album.lowercase() }, { it.track }))
                Artist(name, sorted, list.map { it.albumId }.distinct().size)
            }
            .sortedBy { it.name.lowercase() }

    /**
     * Artista principale sotto cui raggruppare il brano: si usa il tag "album artist"
     * quando c'è, altrimenti si toglie la parte di collaborazione ("X feat. Y" -> "X").
     * Non si spezza su "&" o virgola per non rompere nomi come "Earth, Wind & Fire".
     */
    fun primaryArtistName(song: Song): String {
        val aa = song.albumArtist.trim()
        if (aa.isNotBlank() && !aa.equals("<unknown>", true) && aa != MediaStore.UNKNOWN_STRING) return aa
        return stripFeatured(song.artist)
    }

    private fun stripFeatured(artist: String): String {
        val lower = artist.lowercase()
        val markers = listOf(" feat", " ft.", " ft ", " featuring", " (feat", " (ft", " f/ ", " w/ ", " con ")
        var cut = artist.length
        for (m in markers) {
            val i = lower.indexOf(m)
            if (i in 0 until cut) cut = i
        }
        val s = artist.substring(0, cut).trim().trimEnd(',', '(', '-', ' ')
        return s.ifBlank { artist }
    }

    private fun String?.orFallback(fallback: String): String =
        if (this.isNullOrBlank() || this == MediaStore.UNKNOWN_STRING) fallback else this
}
