package com.personale.musica.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.Player
import com.personale.musica.data.Album
import com.personale.musica.data.Artist
import com.personale.musica.data.Genre
import com.personale.musica.data.MusicRepository

private val audioPermission: String
    get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun requestedPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPermission, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(audioPermission)

private fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED

@Composable
fun MusicApp(player: Player?, vm: LibraryViewModel = viewModel()) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission(context)
    }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(requestedPermissions())
    }
    LaunchedEffect(granted) {
        if (granted) vm.load()
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (granted) {
            LibraryRoot(vm, player)
        } else {
            PermissionScreen { launcher.launch(requestedPermissions()) }
        }
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "Ciao!",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Per mostrarti la tua musica l'app deve poter leggere i file audio del telefono. " +
                "Non usa internet: niente lascia il dispositivo.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequest) { Text("Consenti accesso alla musica") }
        Spacer(Modifier.height(12.dp))
        Text(
            "Se il pulsante non fa nulla: Impostazioni › App › La mia musica › Autorizzazioni.",
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun LibraryRoot(vm: LibraryViewModel, player: Player?) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val albums by vm.albums.collectAsStateWithLifecycle()
    val artists by vm.artists.collectAsStateWithLifecycle()
    val genres by vm.genres.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val state = rememberPlayerState(player)

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var openAlbum by remember { mutableStateOf<Album?>(null) }
    var openArtist by remember { mutableStateOf<Artist?>(null) }
    var openGenre by remember { mutableStateOf<Genre?>(null) }
    var nowPlaying by rememberSaveable { mutableStateOf(false) }

    val currentSong = remember(state.mediaId, songs) {
        state.mediaId?.toLongOrNull()?.let { MusicRepository.songById(it) }
    }
    val play: PlayAction = { list, index, shuffle -> player?.playSongs(list, index, shuffle) }

    BackHandler(enabled = !nowPlaying && (openAlbum != null || openArtist != null || openGenre != null)) {
        when {
            openAlbum != null -> openAlbum = null
            openArtist != null -> openArtist = null
            else -> openGenre = null
        }
    }
    BackHandler(enabled = nowPlaying) { nowPlaying = false }

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            Box(Modifier.weight(1f)) {
                val album = openAlbum
                val artist = openArtist
                val genre = openGenre
                when {
                    album != null -> AlbumDetail(
                        album = album,
                        currentId = state.mediaId,
                        onBack = { openAlbum = null },
                        onPlay = play,
                    )
                    artist != null -> ArtistDetail(
                        artist = artist,
                        allAlbums = albums,
                        currentId = state.mediaId,
                        onBack = { openArtist = null },
                        onPlay = play,
                        onAlbum = { openAlbum = it },
                    )
                    genre != null -> GenreDetail(
                        genre = genre,
                        currentId = state.mediaId,
                        onBack = { openGenre = null },
                        onPlay = play,
                    )
                    else -> LibraryTabs(
                        tab = tab,
                        onTab = { tab = it },
                        songs = songs,
                        albums = albums,
                        artists = artists,
                        genres = genres,
                        loading = loading,
                        currentId = state.mediaId,
                        onPlay = play,
                        onAlbum = { openAlbum = it },
                        onArtist = { openArtist = it },
                        onGenre = { openGenre = it },
                        onRefresh = { vm.load() },
                    )
                }
            }
            if (state.hasItem) {
                MiniPlayer(state, currentSong, player, onOpen = { nowPlaying = true })
            }
            Spacer(Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
        }

        AnimatedVisibility(
            visible = nowPlaying && state.hasItem,
            enter = slideInVertically { it },
            exit = slideOutVertically { it },
        ) {
            NowPlayingScreen(state, currentSong, player, onClose = { nowPlaying = false })
        }
    }
}
